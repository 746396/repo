javascript
// Multiplication Function
function multiply(num1, num2) {
  return num1 * num2;
}

// Test multiplication function
console.log("Multiplication:");
console.log("3 * 5 =", multiply(3, 5));
console.log("7 * 2 =", multiply(7, 2));

// Addition Function
function add(num1, num2) {
  return num1 + num2;
}

// Test addition function
console.log("\nAddition:");
console.log("3 + 5 =", add(3, 5));
console.log("7 + 2 =", add(7, 2));

// Sum of Numbers with For Loop
function sumWithForLoop(n) {
  let sum = 0;
  for (let i = 1; i <= n; i++) {
    sum += i;
  }
  return sum;
}

// Test sumWithForLoop function
console.log("\nSum of Numbers with For Loop:");
console.log("Sum of numbers from 1 to 5:", sumWithForLoop(5));
console.log("Sum of numbers from 1 to 10:", sumWithForLoop(10));